var classsfl_1_1_sequence_face_landmarks =
[
    [ "addFrame", "classsfl_1_1_sequence_face_landmarks.html#aa65faac1c95fca8d022b1536c6f0c1ff", null ],
    [ "clear", "classsfl_1_1_sequence_face_landmarks.html#a3d94182a1c9dbf68a2942b82233c283a", null ],
    [ "clone", "classsfl_1_1_sequence_face_landmarks.html#a7149b88ae349acdf72261f0e6450e7a9", null ],
    [ "getFrameScale", "classsfl_1_1_sequence_face_landmarks.html#a65155fd9a4340d01ff1ab84e4551b8ba", null ],
    [ "getModel", "classsfl_1_1_sequence_face_landmarks.html#a33a7fdbd56e2fb5fea1c16f05de17ff9", null ],
    [ "getSequence", "classsfl_1_1_sequence_face_landmarks.html#ad6dc7b2cfa59f5da6f7a8c7495f4b445", null ],
    [ "getTrackFaces", "classsfl_1_1_sequence_face_landmarks.html#a6b3a8a64f7d5256693783f00c0224d3a", null ],
    [ "load", "classsfl_1_1_sequence_face_landmarks.html#a882661b3709c4cd5d890a5ed1f24c955", null ],
    [ "save", "classsfl_1_1_sequence_face_landmarks.html#af092dfa695e5545fd81d46e5a979d618", null ],
    [ "setFrameScale", "classsfl_1_1_sequence_face_landmarks.html#afa114202b21f424fe084b251af3f02c7", null ],
    [ "setModel", "classsfl_1_1_sequence_face_landmarks.html#af8301c10711fe624c3b560553293aed8", null ],
    [ "setTrackFaces", "classsfl_1_1_sequence_face_landmarks.html#a8b66f80e32dd7ea688688536d1ab0a37", null ],
    [ "size", "classsfl_1_1_sequence_face_landmarks.html#a853eed169a52b9ae27d20a0fff9a8392", null ]
];