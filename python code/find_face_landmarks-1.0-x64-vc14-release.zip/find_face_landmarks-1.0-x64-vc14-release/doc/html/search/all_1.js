var searchData=
[
  ['bbox',['bbox',['../structsfl_1_1_face.html#a70310c5cb6bf1b46e13deae7cc2b7c34',1,'sfl::Face']]]
];
