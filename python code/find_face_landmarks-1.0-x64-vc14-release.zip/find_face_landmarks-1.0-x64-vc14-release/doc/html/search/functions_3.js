var searchData=
[
  ['load',['load',['../classsfl_1_1_sequence_face_landmarks.html#a882661b3709c4cd5d890a5ed1f24c955',1,'sfl::SequenceFaceLandmarks']]]
];
