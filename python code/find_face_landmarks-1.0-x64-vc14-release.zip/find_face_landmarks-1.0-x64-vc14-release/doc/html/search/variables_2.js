var searchData=
[
  ['central_5fratio',['central_ratio',['../structsfl_1_1_face_stat.html#aa867e5017147347646a3877683163691',1,'sfl::FaceStat']]]
];
