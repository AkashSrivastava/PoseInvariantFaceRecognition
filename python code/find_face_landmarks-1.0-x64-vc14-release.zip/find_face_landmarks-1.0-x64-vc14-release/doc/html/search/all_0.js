var searchData=
[
  ['addframe',['addFrame',['../classsfl_1_1_face_tracker.html#abfb36cadc320549ad77ddded36b41f40',1,'sfl::FaceTracker::addFrame()'],['../classsfl_1_1_sequence_face_landmarks.html#aa65faac1c95fca8d022b1536c6f0c1ff',1,'sfl::SequenceFaceLandmarks::addFrame()']]],
  ['avg_5fcenter_5fdist',['avg_center_dist',['../structsfl_1_1_face_stat.html#a59940a307b75881cdab283ba5ab608ed',1,'sfl::FaceStat']]],
  ['avg_5fsize',['avg_size',['../structsfl_1_1_face_stat.html#a6bc011767a7d35c666f30c678f463f4a',1,'sfl::FaceStat']]]
];
