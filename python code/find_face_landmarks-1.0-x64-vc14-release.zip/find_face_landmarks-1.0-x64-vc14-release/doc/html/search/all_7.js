var searchData=
[
  ['landmarks',['landmarks',['../structsfl_1_1_face.html#a02d2353b591b486d22045cb8e91310f3',1,'sfl::Face']]],
  ['load',['load',['../classsfl_1_1_sequence_face_landmarks.html#a882661b3709c4cd5d890a5ed1f24c955',1,'sfl::SequenceFaceLandmarks']]]
];
