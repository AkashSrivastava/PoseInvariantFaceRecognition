var searchData=
[
  ['getface',['getFace',['../structsfl_1_1_frame.html#ad8a48313acdb71b1b408de3c53fdf892',1,'sfl::Frame']]],
  ['getframescale',['getFrameScale',['../classsfl_1_1_sequence_face_landmarks.html#a65155fd9a4340d01ff1ab84e4551b8ba',1,'sfl::SequenceFaceLandmarks']]],
  ['getmainfaceid',['getMainFaceID',['../utilities_8h.html#aa730b6f3050bb45fa25bc2246e514f83',1,'sfl::getMainFaceID(const std::list&lt; std::unique_ptr&lt; Frame &gt;&gt; &amp;sequence)'],['../utilities_8h.html#a666768c3073396959ae814f5745e591b',1,'sfl::getMainFaceID(const std::vector&lt; FaceStat &gt; &amp;stats)']]],
  ['getmodel',['getModel',['../classsfl_1_1_sequence_face_landmarks.html#a33a7fdbd56e2fb5fea1c16f05de17ff9',1,'sfl::SequenceFaceLandmarks']]],
  ['getsequence',['getSequence',['../classsfl_1_1_sequence_face_landmarks.html#ad6dc7b2cfa59f5da6f7a8c7495f4b445',1,'sfl::SequenceFaceLandmarks']]],
  ['getsequencestats',['getSequenceStats',['../utilities_8h.html#a0bb848f83b16c6617cb3f083303b9275',1,'sfl']]],
  ['gettrackfaces',['getTrackFaces',['../classsfl_1_1_sequence_face_landmarks.html#a6b3a8a64f7d5256693783f00c0224d3a',1,'sfl::SequenceFaceLandmarks']]]
];
