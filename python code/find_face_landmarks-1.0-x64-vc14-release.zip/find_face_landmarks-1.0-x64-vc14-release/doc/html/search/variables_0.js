var searchData=
[
  ['avg_5fcenter_5fdist',['avg_center_dist',['../structsfl_1_1_face_stat.html#a59940a307b75881cdab283ba5ab608ed',1,'sfl::FaceStat']]],
  ['avg_5fsize',['avg_size',['../structsfl_1_1_face_stat.html#a6bc011767a7d35c666f30c678f463f4a',1,'sfl::FaceStat']]]
];
