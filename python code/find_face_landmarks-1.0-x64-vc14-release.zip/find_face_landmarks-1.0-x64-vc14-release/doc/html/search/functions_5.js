var searchData=
[
  ['save',['save',['../classsfl_1_1_sequence_face_landmarks.html#af092dfa695e5545fd81d46e5a979d618',1,'sfl::SequenceFaceLandmarks']]],
  ['setframescale',['setFrameScale',['../classsfl_1_1_sequence_face_landmarks.html#afa114202b21f424fe084b251af3f02c7',1,'sfl::SequenceFaceLandmarks']]],
  ['setmodel',['setModel',['../classsfl_1_1_sequence_face_landmarks.html#af8301c10711fe624c3b560553293aed8',1,'sfl::SequenceFaceLandmarks']]],
  ['settrackfaces',['setTrackFaces',['../classsfl_1_1_sequence_face_landmarks.html#a8b66f80e32dd7ea688688536d1ab0a37',1,'sfl::SequenceFaceLandmarks']]],
  ['size',['size',['../classsfl_1_1_sequence_face_landmarks.html#a853eed169a52b9ae27d20a0fff9a8392',1,'sfl::SequenceFaceLandmarks']]]
];
