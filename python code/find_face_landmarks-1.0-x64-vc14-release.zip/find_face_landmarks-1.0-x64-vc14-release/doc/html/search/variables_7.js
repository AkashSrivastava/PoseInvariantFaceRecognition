var searchData=
[
  ['size_5fratio',['size_ratio',['../structsfl_1_1_face_stat.html#aba5b71da5eecde922a0276fba055a6d7',1,'sfl::FaceStat']]]
];
