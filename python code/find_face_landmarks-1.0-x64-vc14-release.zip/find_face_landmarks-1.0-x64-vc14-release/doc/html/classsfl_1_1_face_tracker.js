var classsfl_1_1_face_tracker =
[
    [ "addFrame", "classsfl_1_1_face_tracker.html#abfb36cadc320549ad77ddded36b41f40", null ],
    [ "clear", "classsfl_1_1_face_tracker.html#a7694dff4282c45f6f087db3dbda8a06d", null ],
    [ "clone", "classsfl_1_1_face_tracker.html#a17d82fb1d0c8a8f984124712fd3a33d5", null ]
];